import java.util.Scanner;

public class CalificadorNotas {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Introduzca su nota: ");
        float note = sc.nextFloat();
        switch ((int)note){
            case 1:
                System.out.println("Nota invalida");
                break;
            case 2:
                System.out.println("Suspenso");
                break;
            case 3:
            case 4:
                System.out.println("Aprobado");
            break;
            case 5:
                System.out.println("Exelente");
            break;

        }

    }
}
