import java.util.Scanner;
public class CalculoMC {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Ingrese el peso en kilogramos: ");
    double peso = sc.nextDouble();
    
    System.out.print("Ingrese la estatura en metros: ");
    double estatura = sc.nextDouble();
    
    double IMC = peso / (estatura * estatura);
    
    System.out.println("El índice de masa corporal (IMC) es: " + IMC);
 }
}
