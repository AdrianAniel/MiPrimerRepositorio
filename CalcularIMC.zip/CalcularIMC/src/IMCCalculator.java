import java.util.Scanner;

public class IMCCalculator {
    public static void main(String[] args){
       
    try (Scanner scanner = new Scanner(System.in)) {
        System.out.println("Ingrese su peso en kilogramos:");
           double peso = scanner.nextDouble();
           System.out.println("Ingrese su altura en metros:");
           double altura = scanner.nextDouble();
           double imc = calcularIMC(peso, altura);
           System.out.println("Su indice de masa corporal es: "+ imc);
    }
    }
    public static double calcularIMC(double peso, double altura){
        double imc = peso / Math.pow(altura, 2);
        return imc;
    }
}
