import java.util.Scanner;

public class ParImpar {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {

            System.out.print("Ingrese un número entero positivo: ");
            int numero = scanner.nextInt();
            
            if (numero % 2 == 0) {
                System.out.println("El número ingresado es par.");
            } else {
                System.out.println("El número ingresado es impar.");
            }
        }
    }
}