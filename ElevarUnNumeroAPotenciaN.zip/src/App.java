import java.util.Scanner;

public class App {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.println("Ingrese el valor de n: ");
            long n = scanner.nextLong();

            // Calculamos el exponente efectivo
            long exponente = n % 20;

            // Elevamos 5 al exponente efectivo
            long resultado = pow(5, exponente, 100);

            // Imprimimos los dos últimos dígitos del resultado
            System.out.printf("Los dos últimos dígitos de 5^n son: %02d\n", resultado);
        }
    }

    // Implementación de la función pow con modularización
    public static long pow(long base, long exponente, long modulo) {
        long resultado = 1;
        while (exponente > 0) {
            if (exponente % 2 == 1) {
                resultado = (resultado * base) % modulo;
            }
            base = (base * base) % modulo;
            exponente = exponente / 2;
        }
        return resultado;
    }
}